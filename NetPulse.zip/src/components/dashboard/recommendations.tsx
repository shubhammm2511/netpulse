import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { personalizedAutomationRecommendations } from '@/ai/flows/personalized-automation-recommendations';
import { CheckCircle2 } from 'lucide-react';

// Mock data for demonstration purposes
const mockUserData = {
  userBehavior: 'User frequently creates tasks related to customer onboarding and follow-ups. Spends significant time in the customer management section. Has not explored task templates.',
  taskHistory: 'Created 15 tasks for sending welcome emails. Manually created 20 tasks for scheduling follow-up calls with new customers. Automated one task for lead assignment.',
};

export async function Recommendations() {
  const { recommendations } = await personalizedAutomationRecommendations(mockUserData);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Personalized Recommendations</CardTitle>
        <CardDescription>
          Based on your activity, here are some automations you might find useful.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-4">
          {recommendations.map((rec, index) => (
            <li key={index} className="flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
              <span className="text-sm">{rec}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
