import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export function SpecialOffers() {
  return (
    <div>
      <h2 className="text-2xl font-bold font-headline mb-4">For You</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="overflow-hidden">
          <Image
            src="https://picsum.photos/600/300?random=1"
            alt="Entertainment offer"
            width={600}
            height={300}
            className="w-full h-40 object-cover"
            data-ai-hint="entertainment streaming"
          />
          <CardHeader>
            <CardTitle>Entertainment Plus</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">Get 3 months of your favorite streaming service on us.</p>
            <Button>Claim Now</Button>
          </CardContent>
        </Card>
        <Card className="overflow-hidden">
          <Image
            src="https://picsum.photos/600/300?random=2"
            alt="Data offer"
            width={600}
            height={300}
            className="w-full h-40 object-cover"
            data-ai-hint="internet speed"
          />
          <CardHeader>
            <CardTitle>Data Booster</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">Add 10GB of high-speed data for just ₹5.</p>
            <Button>Get Booster</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
