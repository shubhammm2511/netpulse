// src/components/dashboard/telco/quick-actions.tsx
'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Smartphone, Zap, Gift, Headphones, CreditCard, Signal } from 'lucide-react';
import Link from 'next/link';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';

const actions = [
  { label: 'Recharge', icon: Smartphone, href: '/payments' },
  { label: 'Pay Bills', icon: CreditCard, href: '/payments' },
  { label: 'Data Booster', icon: Signal, href: '#', isDialog: true },
  { label: 'Special Offers', icon: Gift, href: '#' },
  { label: 'Support', icon: Headphones, href: 'mailto:support@netpulse.com' },
];

const dataBoosters = [
  { id: 'db1', price: 19, data: '1 GB', description: '1 day validity' },
  { id: 'db2', price: 29, data: '2 GB', description: '2 days validity' },
  { id: 'db3', price: 58, data: '3 GB', description: 'Until active plan' },
];

export function QuickActions() {
  const [isBoosterDialogOpen, setIsBoosterDialogOpen] = useState(false);
  const [selectedBooster, setSelectedBooster] = useState<string | null>(null);
  const router = useRouter();

  const handleProceedToPayment = () => {
    if (selectedBooster) {
      const booster = dataBoosters.find(b => b.id === selectedBooster);
      if (booster) {
        const description = `Payment for ${booster.data} Data Booster`;
        router.push(`/payments?amount=${booster.price}&description=${encodeURIComponent(description)}`);
      }
    }
  };
  
  const renderAction = (action: any) => {
    if (action.isDialog) {
      return (
        <Dialog open={isBoosterDialogOpen} onOpenChange={setIsBoosterDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className="flex flex-col h-24 w-full gap-2">
              <action.icon className="h-6 w-6 text-primary" />
              <span>{action.label}</span>
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Data Booster</DialogTitle>
              <DialogDescription>
                Need more data? Choose a booster pack to stay connected.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <RadioGroup onValueChange={setSelectedBooster}>
                {dataBoosters.map((booster) => (
                  <Label
                    key={booster.id}
                    htmlFor={booster.id}
                    className="flex items-center justify-between p-4 rounded-lg border has-[:checked]:border-primary"
                  >
                    <div className="flex items-center gap-4">
                      <RadioGroupItem value={booster.id} id={booster.id} />
                      <div>
                        <p className="font-semibold">{booster.data}</p>
                        <p className="text-sm text-muted-foreground">{booster.description}</p>
                      </div>
                    </div>
                    <p className="font-bold">₹{booster.price}</p>
                  </Label>
                ))}
              </RadioGroup>
            </div>
            <DialogFooter>
              <Button disabled={!selectedBooster} onClick={handleProceedToPayment}>
                Proceed to Pay
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      );
    }
    return (
      <Link href={action.href} key={action.label} passHref>
        <Button variant="outline" className="flex flex-col h-24 w-full gap-2">
          <action.icon className="h-6 w-6 text-primary" />
          <span>{action.label}</span>
        </Button>
      </Link>
    );
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {actions.map((action) => (
          <div key={action.label}>{renderAction(action)}</div>
        ))}
      </CardContent>
    </Card>
  );
}
