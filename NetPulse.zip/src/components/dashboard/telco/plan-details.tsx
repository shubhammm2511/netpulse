
'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Wifi, Phone, MessageSquare, Radio, CheckCircle, Bell } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { format, addMonths } from 'date-fns';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

interface Plan {
  name: string;
  price: number;
  validity: number;
  data: string;
}

const initialPlans: Plan[] = [
  {
    name: 'Standard Plan',
    price: 299,
    validity: 28,
    data: '1.5 GB/Day',
  },
  {
    name: 'Gold Tier',
    price: 479,
    validity: 56,
    data: '2 GB/Day',
  },
  {
    name: 'Platinum Tier',
    price: 719,
    validity: 84,
    data: '2.5 GB/Day',
  },
];

export function PlanDetails() {
  const [currentPlanName, setCurrentPlanName] = useState('Gold Tier');
  const [nextPlanName, setNextPlanName] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const nextBillDate = addMonths(new Date(), 1);
  const formattedDate = format(nextBillDate, 'MMMM d, yyyy');

  const currentPlan = initialPlans.find(p => p.name === currentPlanName) || initialPlans[1];

  const handleSelectPlan = (planName: string) => {
    setNextPlanName(planName);
    setIsDialogOpen(false);
    toast({
      title: 'Plan Change Scheduled',
      description: `${planName} will become active on ${formattedDate}.`,
    });
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>Your Active Plan</CardTitle>
            <CardDescription>{currentPlan.name} - 5G Unlimited</CardDescription>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Next bill on</p>
            <p className="font-semibold">{formattedDate}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6 flex-1">
        {nextPlanName && (
          <div className="p-3 rounded-lg bg-blue-50 border border-blue-200 text-blue-800 flex items-center gap-3">
            <Bell className="h-5 w-5" />
            <div className="text-sm">
              <span className="font-semibold">{nextPlanName}</span> is scheduled to start on {formattedDate}.
            </div>
          </div>
        )}
        <div>
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center gap-2">
              <Wifi className="h-5 w-5 text-primary" />
              <span className="font-medium">Data</span>
            </div>
            <span className="text-sm font-semibold">12.5 / 20 GB used</span>
          </div>
          <Progress value={62.5} />
          <p className="text-xs text-muted-foreground mt-1">22 days left</p>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Phone className="h-5 w-5 text-primary" />
              <span className="font-medium">Calls</span>
            </div>
            <p className="text-2xl font-bold">Unlimited</p>
            <p className="text-sm text-muted-foreground">National</p>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <MessageSquare className="h-5 w-5 text-primary" />
              <span className="font-medium">SMS</span>
            </div>
            <p className="text-2xl font-bold">850</p>
            <p className="text-sm text-muted-foreground">out of 1000</p>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline">Manage Plan</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[625px]">
            <DialogHeader>
              <DialogTitle>Change Your Plan</DialogTitle>
              <DialogDescription>
                Select a new plan that fits your needs. Your new plan will activate after your current cycle ends.
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-4">
              {initialPlans.map((plan) => {
                const isCurrent = plan.name === currentPlanName;
                const isNext = plan.name === nextPlanName;
                return (
                 <Card key={plan.name} className={`flex flex-col ${isCurrent ? 'border-primary' : ''} ${isNext ? 'border-blue-500' : ''}`}>
                    <CardHeader>
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-lg">{plan.name}</CardTitle>
                        {isCurrent && <Badge variant="default">Current</Badge>}
                        {isNext && <Badge className="bg-blue-100 text-blue-800">Next</Badge>}
                      </div>
                      <p className="text-2xl font-bold">₹{plan.price}</p>
                    </CardHeader>
                    <CardContent className="flex-1 space-y-2 text-sm text-muted-foreground">
                      <p><span className="font-semibold text-foreground">{plan.validity}</span> Days Validity</p>
                      <p><span className="font-semibold text-foreground">{plan.data}</span> Data</p>
                      <p>Unlimited Calls & SMS</p>
                    </CardContent>
                    <CardFooter>
                      <Button
                        className="w-full"
                        disabled={isCurrent}
                        onClick={() => handleSelectPlan(plan.name)}
                      >
                        {isCurrent ? <CheckCircle className="mr-2 h-4 w-4"/> : <Radio className="mr-2 h-4 w-4"/>}
                        {isCurrent ? 'Current Plan' : isNext ? 'Selected' : 'Select Plan'}
                      </Button>
                    </CardFooter>
                  </Card>
                );
              })}
            </div>
          </DialogContent>
        </Dialog>
      </CardFooter>
    </Card>
  );
}
