'use client';
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Lightbulb, Loader2, ThumbsUp } from 'lucide-react';
import { suggestOptimalWorkflows, SuggestOptimalWorkflowsOutput } from '@/ai/flows/suggest-optimal-workflows';
import { useToast } from '@/hooks/use-toast';

export function SuggestWorkflow() {
  const [needs, setNeeds] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SuggestOptimalWorkflowsOutput | null>(null);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!needs.trim()) return;

    setLoading(true);
    setResult(null);
    try {
      const response = await suggestOptimalWorkflows({ userNeeds: needs });
      setResult(response);
    } catch (error) {
      console.error('Error suggesting workflows:', error);
      toast({
        title: 'Error',
        description: 'Failed to get workflow suggestions. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <Card className="flex flex-col">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="text-accent" />
          <span>Suggest Optimal Workflows</span>
        </CardTitle>
        <CardDescription>
          Describe a repetitive task, and our AI will suggest an automation workflow for you.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col gap-4">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Textarea
            placeholder="e.g., 'When a new customer signs up, send them a welcome email and create a task for a follow-up call.'"
            value={needs}
            onChange={(e) => setNeeds(e.target.value)}
            rows={4}
            disabled={loading}
          />
          <Button type="submit" disabled={loading || !needs.trim()} className="w-full bg-accent hover:bg-accent/90">
            {loading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Lightbulb className="mr-2 h-4 w-4" />
            )}
            Get Suggestions
          </Button>
        </form>
        {result && (
          <div className="mt-4 p-4 bg-secondary/50 rounded-lg space-y-4 animate-in fade-in-50">
            <div>
              <h4 className="font-semibold mb-2">Workflow Suggestions:</h4>
              <ul className="list-disc list-inside space-y-1 text-sm">
                {result.workflowSuggestions.map((suggestion, index) => (
                  <li key={index}>{suggestion}</li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Reasoning:</h4>
              <p className="text-sm text-muted-foreground">{result.reasoning}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
