'use client';
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart';

const chartData = [
  { date: 'Mon', completed: 120, running: 30, errored: 8 },
  { date: 'Tue', completed: 150, running: 25, errored: 5 },
  { date: 'Wed', completed: 130, running: 35, errored: 12 },
  { date: 'Thu', completed: 180, running: 20, errored: 3 },
  { date: 'Fri', completed: 210, running: 15, errored: 2 },
  { date: 'Sat', completed: 90, running: 40, errored: 15 },
  { date: 'Sun', completed: 110, running: 28, errored: 7 },
];

const chartConfig = {
  completed: {
    label: 'Completed',
    color: 'hsl(var(--primary))',
  },
  running: {
    label: 'Running',
    color: 'hsl(var(--secondary))',
  },
  errored: {
    label: 'Errored',
    color: 'hsl(var(--destructive))',
  },
} satisfies ChartConfig;

export function TaskProgress() {
  return (
    <Card className="lg:col-span-2">
      <CardHeader>
        <CardTitle>Task Progress</CardTitle>
        <CardDescription>Automated tasks summary for the last 7 days.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] w-full">
          <ChartContainer config={chartConfig} className="min-h-[200px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="date" tickLine={false} axisLine={false} />
                <YAxis tickLine={false} axisLine={false} />
                <Tooltip
                  content={<ChartTooltipContent indicator="dot" />}
                  cursor={{ fill: 'hsl(var(--background))' }}
                />
                <Legend />
                <Bar dataKey="completed" fill="var(--color-completed)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="running" fill="var(--color-running)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="errored" fill="var(--color-errored)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </div>
      </CardContent>
    </Card>
  );
}
