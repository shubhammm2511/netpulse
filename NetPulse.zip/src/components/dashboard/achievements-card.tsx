import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge, Bot, Zap, Award } from 'lucide-react';

export function AchievementsCard() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Progress</CardTitle>
        <CardDescription>Keep automating to level up!</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          <p className="text-sm text-muted-foreground">Automation Points</p>
          <p className="text-4xl font-bold">1,250</p>
        </div>
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>Level 5: Automation Pro</span>
            <span className="font-semibold">250 / 500 XP</span>
          </div>
          <Progress value={50} />
        </div>
        <div>
          <h4 className="text-sm font-semibold mb-2">Recent Badges</h4>
          <div className="flex justify-center gap-4 text-primary">
            <div className="flex flex-col items-center gap-1 text-center">
              <div className="p-3 bg-secondary rounded-full">
                <Zap className="h-6 w-6" />
              </div>
              <span className="text-xs text-muted-foreground">First Trigger</span>
            </div>
            <div className="flex flex-col items-center gap-1 text-center">
              <div className="p-3 bg-secondary rounded-full">
                <Bot className="h-6 w-6" />
              </div>
              <span className="text-xs text-muted-foreground">10 Automations</span>
            </div>
            <div className="flex flex-col items-center gap-1 text-center">
             <div className="p-3 bg-secondary rounded-full">
                <Award className="h-6 w-6" />
              </div>
              <span className="text-xs text-muted-foreground">Power User</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
