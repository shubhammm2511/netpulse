
'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Signal } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

const GoogleIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 48 48" {...props}>
    <title>Google Logo</title>
    <clipPath id="g">
      <path d="M44.5 20H24v8.5h11.8C34.7 33.9 30.1 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 11.8 2 2 11.8 2 24s9.8 22 22 22c11 0 21-8 21-22 0-1.3-.2-2.7-.5-4z" />
    </clipPath>
    <g clipPath="url(#g)">
      <path fill="#FBBC05" d="M0 37V11l17 13z" />
      <path fill="#EA4335" d="M0 11l17 13 7-6.1L48 14V0H0z" />
      <path fill="#34A853" d="M0 37l30-23 7.9 1L48 0v48H0z" />
      <path fill="#4285F4" d="M48 48L17 24l-4-3 35-10z" />
    </g>
  </svg>
);


export default function LoginPage() {
    const router = useRouter();

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        router.push('/dashboard');
    };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-gray-900 p-4">
       <div className="absolute top-8 left-8 flex items-center gap-2">
         <Signal className="h-8 w-8 text-primary" />
         <span className="text-2xl font-semibold font-headline">Netpulse</span>
       </div>
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Log in or sign up</CardTitle>
          <CardDescription>Enter your mobile number to get started. Any number will work.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="phone">Mobile Number</Label>
              <div className="flex items-center gap-2">
                <div className="rounded-md border bg-gray-100 p-2 text-sm dark:bg-gray-800">+91</div>
                <Input id="phone" type="tel" placeholder="Enter your mobile number" className="flex-1" required />
              </div>
            </div>
            <Button type="submit" className="w-full">
              Send OTP
            </Button>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">
                Or continue with
              </span>
            </div>
          </div>
          
            <Button variant="outline" className="w-full" onClick={() => router.push('/dashboard')}>
                <GoogleIcon className="mr-2 h-5 w-5" />
                Sign in with Google
            </Button>

        </CardContent>
        <CardFooter className="text-center text-xs text-muted-foreground">
            <p>
            By continuing, you agree to our <Link href="#" className="underline">Terms of Service</Link> and <Link href="#" className="underline">Privacy Policy</Link>.
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}
