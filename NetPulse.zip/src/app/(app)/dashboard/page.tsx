import { PlanDetails } from '@/components/dashboard/telco/plan-details';
import { QuickActions } from '@/components/dashboard/telco/quick-actions';
import { UsageSummary } from '@/components/dashboard/telco/usage-summary';
import { SpecialOffers } from '@/components/dashboard/telco/special-offers';

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <PlanDetails />
        </div>
        <UsageSummary />
      </div>
      <QuickActions />
      <SpecialOffers />
    </div>
  );
}
