
'use client';

import React, { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PlusCircle, ArrowUpDown, MoreHorizontal } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const initialCustomers = [
  { id: 1, name: 'Priya Sharma', email: 'priya.sharma@gmail.com', status: 'Active', lifetimeValue: 6200 },
  { id: 2, name: 'Rohan Gupta', email: 'rohan.gupta@gmail.com', status: 'Active', lifetimeValue: 4800 },
  { id: 3, name: 'Anjali Verma', email: 'anjali.verma@gmail.com', status: 'Churned', lifetimeValue: 1200 },
  { id: 4, name: 'Vikram Singh', email: 'vikram.singh@gmail.com', status: 'New', lifetimeValue: 150 },
  { id: 5, name: 'Aditi Joshi', email: 'aditi.joshi@gmail.com', status: 'Active', lifetimeValue: 8900 },
];

type CustomerStatus = 'Active' | 'Churned' | 'New';

interface Customer {
  id: number;
  name: string;
  email: string;
  status: CustomerStatus;
  lifetimeValue: number;
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
  const [isAddCustomerDialogOpen, setIsAddCustomerDialogOpen] = useState(false);
  const [isEditLtvDialogOpen, setIsEditLtvDialogOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [newLtv, setNewLtv] = useState('');
  const [newCustomer, setNewCustomer] = useState({ name: '', email: '' });

  const handleAddCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCustomer.name && newCustomer.email) {
      const newId = customers.length > 0 ? Math.max(...customers.map(c => c.id)) + 1 : 1;
      setCustomers([
        ...customers,
        {
          id: newId,
          ...newCustomer,
          status: 'New',
          lifetimeValue: 0,
        },
      ]);
      setNewCustomer({ name: '', email: '' });
      setIsAddCustomerDialogOpen(false);
    }
  };

  const handleStatusChange = (customerId: number, status: CustomerStatus) => {
    setCustomers(customers.map(c => c.id === customerId ? { ...c, status } : c));
  };

  const handleEditLtvClick = (customer: Customer) => {
    setEditingCustomer(customer);
    setNewLtv(customer.lifetimeValue.toString());
    setIsEditLtvDialogOpen(true);
  };

  const handleSaveLtv = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCustomer && newLtv) {
      setCustomers(customers.map(c =>
        c.id === editingCustomer.id ? { ...c, lifetimeValue: parseFloat(newLtv) } : c
      ));
      setIsEditLtvDialogOpen(false);
      setEditingCustomer(null);
      setNewLtv('');
    }
  };


  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold font-headline">Customers</h1>
          <p className="text-muted-foreground">View and manage your customer accounts.</p>
        </div>
        <Dialog open={isAddCustomerDialogOpen} onOpenChange={setIsAddCustomerDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <PlusCircle className="mr-2 h-4 w-4" />
              New Customer
            </Button>
          </DialogTrigger>
          <DialogContent>
            <form onSubmit={handleAddCustomer}>
              <DialogHeader>
                <DialogTitle>Add New Customer</DialogTitle>
                <DialogDescription>
                  Enter the details for the new customer account.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">Name</Label>
                  <Input
                    id="name"
                    placeholder="e.g., Priya Sharma"
                    className="col-span-3"
                    value={newCustomer.name}
                    onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="email" className="text-right">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="e.g., priya.sharma@gmail.com"
                    className="col-span-3"
                    value={newCustomer.email}
                    onChange={(e) => setNewCustomer({ ...newCustomer, email: e.target.value })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Add Customer</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="border rounded-lg shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Customer</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>
                <Button variant="ghost" className="p-0 hover:bg-transparent">
                  Lifetime Value
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead><span className="sr-only">Actions</span></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {customers.map((customer) => (
              <TableRow key={customer.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={`https://picsum.photos/40/40?random=${customer.id}`} data-ai-hint="person" />
                      <AvatarFallback>{customer.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{customer.name}</div>
                      <div className="text-sm text-muted-foreground">{customer.email}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge
                    variant={
                      customer.status === 'Active' ? 'default'
                      : customer.status === 'New' ? 'outline'
                      : 'secondary'
                    }
                    className={
                      customer.status === 'Active' ? 'bg-green-500/20 text-green-700 hover:bg-green-500/30'
                      : customer.status === 'New' ? 'text-blue-700 border-blue-500/50'
                      : ''
                    }
                  >
                    {customer.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  ₹{customer.lifetimeValue.toLocaleString()}
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleStatusChange(customer.id, 'Active')}>
                        Mark as Active
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleStatusChange(customer.id, 'Churned')}>
                        Mark as Churned
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleEditLtvClick(customer)}>
                        Edit Lifetime Value
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={isEditLtvDialogOpen} onOpenChange={setIsEditLtvDialogOpen}>
          <DialogContent>
            <form onSubmit={handleSaveLtv}>
              <DialogHeader>
                <DialogTitle>Edit Lifetime Value</DialogTitle>
                <DialogDescription>
                  Update the lifetime value for {editingCustomer?.name}.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="ltv" className="text-right">
                    Lifetime Value (₹)
                  </Label>
                  <Input
                    id="ltv"
                    type="number"
                    className="col-span-3"
                    value={newLtv}
                    onChange={(e) => setNewLtv(e.target.value)}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Save Changes</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
    </div>
  );
}
