
'use client';

import React, { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PlusCircle, MoreHorizontal } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface Automation {
  id: number;
  name: string;
  trigger: string;
  actions: number;
  status: 'Active' | 'Paused';
}

const initialAutomations: Automation[] = [
  { id: 1, name: 'Welcome New Customers', trigger: 'New Customer Created', actions: 2, status: 'Active' },
  { id: 2, name: 'Follow-up on Quotes', trigger: 'Quote Sent > 3 days', actions: 3, status: 'Active' },
  { id: 3, name: 'Monthly Report Generation', trigger: 'First of Month', actions: 1, status: 'Paused' },
  { id: 4, name: 'High-Value Customer Alert', trigger: 'Lifetime Value > ₹5000', actions: 1, status: 'Active' },
];

export default function AutomationsPage() {
  const [automations, setAutomations] = useState<Automation[]>(initialAutomations);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newAutomationName, setNewAutomationName] = useState('');

  const handleCreateAutomation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAutomationName.trim()) return;

    const newAutomation: Automation = {
      id: automations.length > 0 ? Math.max(...automations.map(a => a.id)) + 1 : 1,
      name: newAutomationName,
      trigger: 'New Trigger',
      actions: 1,
      status: 'Paused',
    };

    setAutomations([...automations, newAutomation]);
    setNewAutomationName('');
    setIsDialogOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold font-headline">Automations</h1>
          <p className="text-muted-foreground">Manage your automated workflows.</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <PlusCircle className="mr-2 h-4 w-4" />
              New Automation
            </Button>
          </DialogTrigger>
          <DialogContent>
            <form onSubmit={handleCreateAutomation}>
              <DialogHeader>
                <DialogTitle>Create New Automation</DialogTitle>
                <DialogDescription>
                  Set up a new workflow to automate your tasks.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">Name</Label>
                  <Input 
                    id="name" 
                    placeholder="e.g., Welcome New Customers" 
                    className="col-span-3"
                    value={newAutomationName}
                    onChange={(e) => setNewAutomationName(e.target.value)}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="trigger" className="text-right">Trigger</Label>
                  <Select>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select a trigger" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new-customer">New Customer Created</SelectItem>
                      <SelectItem value="quote-sent">Quote Sent</SelectItem>
                      <SelectItem value="first-of-month">First of Month</SelectItem>
                      <SelectItem value="lifetime-value">Lifetime Value Change</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                 <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="actions" className="text-right">Actions</Label>
                   <Select>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Add an action" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="send-email">Send Email</SelectItem>
                      <SelectItem value="create-task">Create Task</SelectItem>
                      <SelectItem value="send-sms">Send SMS</SelectItem>
                      <SelectItem value="add-tag">Add Tag to Customer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Create Automation</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="border rounded-lg shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Trigger</TableHead>
              <TableHead>Actions</TableHead>
              <TableHead>Status</TableHead>
              <TableHead><span className="sr-only">Actions</span></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {automations.map((automation) => (
              <TableRow key={automation.id}>
                <TableCell className="font-medium">{automation.name}</TableCell>
                <TableCell>{automation.trigger}</TableCell>
                <TableCell>{automation.actions}</TableCell>
                <TableCell>
                  <Badge variant={automation.status === 'Active' ? 'default' : 'secondary'} className={automation.status === 'Active' ? 'bg-green-100 text-green-800' : ''}>
                    {automation.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>Edit</DropdownMenuItem>
                      <DropdownMenuItem>Duplicate</DropdownMenuItem>
                      <DropdownMenuItem className="text-red-600">Delete</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
