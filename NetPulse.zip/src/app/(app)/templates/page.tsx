
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Send, Calendar, BarChart2, Repeat, Star, Heart, IndianRupee, AlertCircle } from 'lucide-react';
import Link from 'next/link';

const templates = [
  {
    title: 'Welcome New Customer',
    description: 'Automatically send a welcome email and create a follow-up task when a new customer is added.',
    icon: Send,
  },
  {
    title: 'Appointment Reminders',
    description: 'Send SMS or email reminders to customers 24 hours before their scheduled appointment.',
    icon: Calendar,
  },
  {
    title: 'Monthly Business Report',
    description: 'Generate and email a summary of key business metrics on the first day of each month.',
    icon: BarChart2,
  },
  {
    title: 'Onboard New Employee',
    description: 'A complete workflow to create user accounts, assign starter tasks, and send welcome info.',
    icon: FileText,
  },
  {
    title: 'Subscription Renewal Reminder',
    description: 'Send a reminder email to customers a week before their subscription is due to expire.',
    icon: Repeat,
  },
  {
    title: 'Customer Feedback Survey',
    description: 'After a project is completed, automatically send a feedback survey to the customer.',
    icon: Star,
  },
  {
    title: 'Lead Nurturing Sequence',
    description: 'Automatically follow up with new leads over a series of emails to keep them engaged.',
    icon: Heart,
  },
  {
    title: 'Failed Payment Follow-up',
    description: 'Notify customers of failed payments and prompt them to update their billing information.',
    icon: AlertCircle,
  },
  {
    title: 'High-Value Customer Reward',
    description: 'Automatically send a special offer or thank-you note to your most valuable customers.',
    icon: IndianRupee,
  },
];

export default function TemplatesPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold font-headline">Task Templates</h1>
        <p className="text-muted-foreground">
          Use pre-built templates to create new automations in seconds.
        </p>
      </div>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        {templates.map((template, index) => (
          <Card key={index} className="flex flex-col">
            <CardHeader className="flex-row items-start gap-4 space-y-0">
              <div className="p-3 bg-primary/10 rounded-lg">
                <template.icon className="h-6 w-6 text-primary" />
              </div>
              <div className="flex-1">
                <CardTitle>{template.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <CardDescription>{template.description}</CardDescription>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full bg-accent hover:bg-accent/90">
                <Link href="/automations">Use Template</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}
