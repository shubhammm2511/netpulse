
import React from 'react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

export default function TutorialsPage() {
  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="text-center">
        <h1 className="text-3xl font-bold font-headline">Interactive Tutorials</h1>
        <p className="text-muted-foreground mt-2">
          Step-by-step guides to help you get the most out of Netpulse.
        </p>
      </div>
      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="item-1">
          <AccordionTrigger className="text-lg font-semibold">
            How to Log In to Netpulse
          </AccordionTrigger>
          <AccordionContent className="space-y-4 p-4">
            <p><strong>Step 1: Open the App</strong><br/>
            Launch the Netpulse application on your device. You will be greeted with the login screen.</p>
            <p><strong>Step 2: Enter Your Credentials</strong><br/>
            Enter your registered mobile number or email address in the designated field. Then, enter your password securely.</p>
            <p><strong>Step 3: Click 'Log In'</strong><br/>
            After entering your credentials, click the "Log In" button to proceed.</p>
            <p><strong>Step 4: Access Your Dashboard</strong><br/>
            Upon successful login, you will be redirected to your personalized dashboard where you can manage your account.</p>
          </AccordionContent>
        </AccordionItem>
        <AccordionItem value="item-2">
          <AccordionTrigger className="text-lg font-semibold">
            Using AI to Suggest Workflows
          </AccordionTrigger>
          <AccordionContent className="space-y-4 p-4">
            <p>Our powerful AI can help you discover new automation opportunities. Go to your dashboard and find the "Suggest Optimal Workflows" card. Describe a task you do often, and the AI will give you tailored suggestions to automate it, complete with the reasoning behind its choices.</p>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}
