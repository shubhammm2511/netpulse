// src/app/(app)/payments/page.tsx
'use client';

import React, { Suspense, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CreditCard, Landmark, QrCode, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useUser } from '@/context/user-context';
import { format, addMonths } from 'date-fns';

function PaymentsContent() {
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const { user } = useUser();
  const [isLoading, setIsLoading] = useState(false);

  const amount = searchParams.get('amount') || '479';
  const description = searchParams.get('description');

  const nextBillDate = addMonths(new Date(), 1);
  const formattedDate = format(nextBillDate, 'MMMM d, yyyy');

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate API call
    setIsLoading(false);
    toast({
      variant: 'success',
      title: 'Payment Successful',
      description: `Your payment of ₹${amount} has been processed.`,
    });
  };

  return (
    <div className="flex justify-center items-start p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Make a Payment</CardTitle>
          <CardDescription>
            {description || `Your bill for the Gold Tier plan is due on ${formattedDate}.`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6 p-4 rounded-lg bg-secondary flex justify-between items-center">
            <div>
              <p className="text-muted-foreground">Amount Due</p>
              <p className="text-3xl font-bold">₹{parseFloat(amount).toFixed(2)}</p>
            </div>
            <div className="text-right">
              <p className="font-semibold">{user.name}</p>
              <p className="text-sm text-muted-foreground">Billed to: {user.email}</p>
            </div>
          </div>

          <Tabs defaultValue="credit-card" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="credit-card">
                <CreditCard className="mr-2 h-4 w-4" />
                Credit Card
              </TabsTrigger>
              <TabsTrigger value="upi">
                <QrCode className="mr-2 h-4 w-4" />
                UPI
              </TabsTrigger>
              <TabsTrigger value="netbanking">
                <Landmark className="mr-2 h-4 w-4" />
                Net Banking
              </TabsTrigger>
            </TabsList>
            <TabsContent value="credit-card">
              <form onSubmit={handlePayment} className="mt-4 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="card-number">Card Number</Label>
                  <Input id="card-number" placeholder="0000 0000 0000 0000" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="expiry">Expiry Date</Label>
                    <Input id="expiry" placeholder="MM/YY" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cvc">CVC</Label>
                    <Input id="cvc" placeholder="123" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="card-holder">Card Holder Name</Label>
                  <Input id="card-holder" placeholder="Shubham" />
                </div>
                <Button type="submit" className="w-full mt-4" disabled={isLoading}>
                  {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {isLoading ? 'Processing...' : `Pay ₹${parseFloat(amount).toFixed(2)}`}
                </Button>
              </form>
            </TabsContent>
            <TabsContent value="upi">
              <div className="mt-4 text-center">
                <p className="text-muted-foreground">Scan the QR code with your UPI app</p>
                <div className="flex justify-center my-4">
                  <QrCode className="h-32 w-32 text-primary" />
                </div>
                <Button className="w-full" onClick={handlePayment} disabled={isLoading}>
                  {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {isLoading ? 'Processing...' : 'Pay with UPI'}
                </Button>
              </div>
            </TabsContent>
             <TabsContent value="netbanking">
              <div className="mt-4 text-center">
                <p className="text-muted-foreground mb-4">You will be redirected to your bank's website to complete the payment.</p>
                <Button className="w-full" onClick={handlePayment} disabled={isLoading}>
                  {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {isLoading ? 'Redirecting...' : 'Proceed to Net Banking'}
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

export default function PaymentsPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <PaymentsContent />
    </Suspense>
  );
}
