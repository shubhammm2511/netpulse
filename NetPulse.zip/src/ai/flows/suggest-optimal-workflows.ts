'use server';

/**
 * @fileOverview An AI agent that suggests optimal automation workflows based on user needs.
 *
 * - suggestOptimalWorkflows - A function that suggests optimal automation workflows.
 * - SuggestOptimalWorkflowsInput - The input type for the suggestOptimalWorkflows function.
 * - SuggestOptimalWorkflowsOutput - The return type for the suggestOptimalWorkflows function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestOptimalWorkflowsInputSchema = z.object({
  userNeeds: z
    .string()
    .describe('The user need for which an automation workflow is desired.'),
  taskHistory: z.string().optional().describe('The history of tasks the user has performed, if any.'),
});
export type SuggestOptimalWorkflowsInput = z.infer<typeof SuggestOptimalWorkflowsInputSchema>;

const SuggestOptimalWorkflowsOutputSchema = z.object({
  workflowSuggestions: z
    .array(z.string())
    .describe('An array of suggested optimal automation workflows.'),
  reasoning: z.string().describe('The reasoning behind the workflow suggestions.'),
});
export type SuggestOptimalWorkflowsOutput = z.infer<typeof SuggestOptimalWorkflowsOutputSchema>;

export async function suggestOptimalWorkflows(
  input: SuggestOptimalWorkflowsInput
): Promise<SuggestOptimalWorkflowsOutput> {
  return suggestOptimalWorkflowsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestOptimalWorkflowsPrompt',
  input: {schema: SuggestOptimalWorkflowsInputSchema},
  output: {schema: SuggestOptimalWorkflowsOutputSchema},
  prompt: `You are an expert in automation workflows. Given the user's needs and task history, suggest optimal automation workflows.

User Needs: {{{userNeeds}}}

Task History: {{{taskHistory}}}

Suggest a few automation workflows that would be helpful for the user, and explain your reasoning.`,
});

const suggestOptimalWorkflowsFlow = ai.defineFlow(
  {
    name: 'suggestOptimalWorkflowsFlow',
    inputSchema: SuggestOptimalWorkflowsInputSchema,
    outputSchema: SuggestOptimalWorkflowsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
