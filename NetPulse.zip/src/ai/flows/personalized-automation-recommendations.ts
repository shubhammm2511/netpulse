// src/ai/flows/personalized-automation-recommendations.ts
'use server';

/**
 * @fileOverview Provides personalized automation recommendations to users based on their past behavior and task history.
 *
 * - personalizedAutomationRecommendations - A function that suggests optimal automation workflows based on user data.
 * - PersonalizedAutomationRecommendationsInput - The input type for the personalizedAutomationRecommendations function.
 * - PersonalizedAutomationRecommendationsOutput - The return type for the personalizedAutomationRecommendations function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PersonalizedAutomationRecommendationsInputSchema = z.object({
  userBehavior: z
    .string()
    .describe('Detailed history of the user interactions within the application.'),
  taskHistory: z
    .string()
    .describe('A comprehensive list of tasks the user has created or automated.'),
});
export type PersonalizedAutomationRecommendationsInput = z.infer<
  typeof PersonalizedAutomationRecommendationsInputSchema
>;

const PersonalizedAutomationRecommendationsOutputSchema = z.object({
  recommendations: z
    .array(z.string())
    .describe('A list of personalized automation recommendations for the user.'),
});
export type PersonalizedAutomationRecommendationsOutput = z.infer<
  typeof PersonalizedAutomationRecommendationsOutputSchema
>;

export async function personalizedAutomationRecommendations(
  input: PersonalizedAutomationRecommendationsInput
): Promise<PersonalizedAutomationRecommendationsOutput> {
  return personalizedAutomationRecommendationsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'personalizedAutomationRecommendationsPrompt',
  input: {schema: PersonalizedAutomationRecommendationsInputSchema},
  output: {schema: PersonalizedAutomationRecommendationsOutputSchema},
  prompt: `Based on the user's behavior and task history, provide personalized automation recommendations.

User Behavior: {{{userBehavior}}}
Task History: {{{taskHistory}}}

Suggest automation workflows that the user might not have considered.
`,
});

const personalizedAutomationRecommendationsFlow = ai.defineFlow(
  {
    name: 'personalizedAutomationRecommendationsFlow',
    inputSchema: PersonalizedAutomationRecommendationsInputSchema,
    outputSchema: PersonalizedAutomationRecommendationsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
