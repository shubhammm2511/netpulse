import { config } from 'dotenv';
config();

import '@/ai/flows/personalized-automation-recommendations.ts';
import '@/ai/flows/suggest-optimal-workflows.ts';